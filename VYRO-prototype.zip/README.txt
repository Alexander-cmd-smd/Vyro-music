VYRO — Feel the Sound
Mobile-first music discovery prototype

HOW TO OPEN ON ANDROID
1. Download and extract VYRO-prototype.zip.
2. Open index.html in a browser, or upload index.html to a free static hosting service.
3. This is a visual/interaction prototype: the sample tracks are fictional and the player does not stream audio.

NOT YET CONNECTED
- Real audio streaming and music licensing
- User accounts and artist uploads
- Database, payments, subscriptions, moderation and analytics

Keep all uploaded music properly licensed or use tracks you own/control.
